I = imread('icon_black_white.png');
figure, imshow(I)
I1=255-I;
figure, imshow(I1);