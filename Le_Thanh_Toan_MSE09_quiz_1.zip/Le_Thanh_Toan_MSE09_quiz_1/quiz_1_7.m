I1 = imread('chess_board.jpeg');
figure(1); imshow(I1);